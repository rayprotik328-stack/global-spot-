import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI lazily
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!genAIClient && process.env.GEMINI_API_KEY) {
    genAIClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return genAIClient;
}

// In-memory cache for ESPN API requests to prevent rate limiting
const cache = new Map<string, { timestamp: number; data: unknown }>();
const CACHE_TTL_MS = 15000; // 15 seconds cache for live score data

async function fetchWithCache(url: string) {
  const cached = cache.get(url);
  const now = Date.now();
  if (cached && now - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) LiveSportsApp/1.0',
      'Accept': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`ESPN API returned status ${response.status}`);
  }

  const data = await response.json();
  cache.set(url, { timestamp: now, data });
  return data;
}

// ==========================================
// SPORTS SCOREBOARD ENDPOINT
// ==========================================
app.get('/api/sports/scoreboard', async (req: Request, res: Response) => {
  const sport = (req.query.sport as string) || 'soccer';
  const league = (req.query.league as string) || 'eng.1';
  const date = (req.query.date as string) || ''; // format YYYYMMDD if provided

  try {
    let espnUrl = `https://site.api.espn.com/apis/site/v2/sports/${sport}/${league}/scoreboard`;
    if (date) {
      espnUrl += `?dates=${date}`;
    }

    const rawData = await fetchWithCache(espnUrl) as {
      leagues?: Array<{ name: string; season?: { year: number } }>;
      events?: Array<any>;
    };

    const leagueName = rawData.leagues?.[0]?.name || league.toUpperCase();
    const seasonYear = rawData.leagues?.[0]?.season?.year || new Date().getFullYear();

    const events = (rawData.events || []).map((event: any) => {
      const competition = event.competitions?.[0] || {};
      const competitors = competition.competitors || [];
      const homeComp = competitors.find((c: any) => c.homeAway === 'home') || competitors[0] || {};
      const awayComp = competitors.find((c: any) => c.homeAway === 'away') || competitors[1] || {};

      const status = event.status || {};
      const state = status.type?.state || 'pre'; // pre, in, post
      const isCompleted = status.type?.completed || false;
      const isLive = state === 'in';
      const detail = status.type?.detail || status.type?.description || 'Scheduled';
      const shortDetail = status.type?.shortDetail || detail;

      // Extract linescores
      const homeLinescores = (homeComp.linescores || []).map((ls: any, idx: number) => ({
        period: idx + 1,
        value: ls.value ?? ls.displayValue ?? 0,
        displayValue: String(ls.value ?? ls.displayValue ?? 0),
      }));

      const awayLinescores = (awayComp.linescores || []).map((ls: any, idx: number) => ({
        period: idx + 1,
        value: ls.value ?? ls.displayValue ?? 0,
        displayValue: String(ls.value ?? ls.displayValue ?? 0),
      }));

      // Extract key recent plays / scoring events
      const recentPlays = (competition.details || []).map((detailItem: any, idx: number) => ({
        id: `play-${idx}-${detailItem.clock?.displayValue || idx}`,
        clock: detailItem.clock?.displayValue || '',
        text: detailItem.text || detailItem.type?.text || 'Event',
        teamId: detailItem.team?.id,
        teamLogo: detailItem.team?.logo,
        teamAbbr: detailItem.team?.abbreviation,
        scoringPlay: detailItem.scoringPlay || false,
        type: detailItem.scoringPlay ? 'goal' : (detailItem.yellowCard ? 'card' : 'general'),
      }));

      // Broadcasts
      const broadcasts = (competition.broadcasts || []).flatMap((b: any) => b.names || []);

      // Odds
      const odds = competition.odds?.[0] ? {
        details: competition.odds[0].details,
        overUnder: competition.odds[0].overUnder,
        spread: competition.odds[0].spread,
      } : undefined;

      return {
        id: event.id,
        uid: event.uid,
        sport,
        league,
        leagueName,
        seasonYear,
        date: event.date,
        status: {
          state,
          detail,
          shortDetail,
          clock: status.displayClock || status.clock,
          period: status.period,
          completed: isCompleted,
          isLive,
        },
        homeTeam: {
          id: homeComp.id || 'home',
          name: homeComp.team?.name || 'Home Team',
          displayName: homeComp.team?.displayName || 'Home Team',
          shortDisplayName: homeComp.team?.shortDisplayName || homeComp.team?.name || 'Home',
          abbreviation: homeComp.team?.abbreviation || 'HOM',
          logo: homeComp.team?.logo || 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/default-team-logo-500.png',
          color: homeComp.team?.color ? `#${homeComp.team.color}` : '#1e293b',
          alternateColor: homeComp.team?.alternateColor ? `#${homeComp.team.alternateColor}` : '#ffffff',
          score: homeComp.score ?? '0',
          records: homeComp.records?.[0]?.summary || '',
          isWinner: homeComp.winner || false,
          linescores: homeLinescores,
        },
        awayTeam: {
          id: awayComp.id || 'away',
          name: awayComp.team?.name || 'Away Team',
          displayName: awayComp.team?.displayName || 'Away Team',
          shortDisplayName: awayComp.team?.shortDisplayName || awayComp.team?.name || 'Away',
          abbreviation: awayComp.team?.abbreviation || 'AWY',
          logo: awayComp.team?.logo || 'https://a.espncdn.com/combiner/i?img=/i/teamlogos/default-team-logo-500.png',
          color: awayComp.team?.color ? `#${awayComp.team.color}` : '#1e293b',
          alternateColor: awayComp.team?.alternateColor ? `#${awayComp.team.alternateColor}` : '#ffffff',
          score: awayComp.score ?? '0',
          records: awayComp.records?.[0]?.summary || '',
          isWinner: awayComp.winner || false,
          linescores: awayLinescores,
        },
        venue: {
          fullName: competition.venue?.fullName || '',
          city: competition.venue?.address?.city || '',
          state: competition.venue?.address?.state || '',
          country: competition.venue?.address?.country || '',
        },
        broadcasts,
        recentPlays,
        odds,
        lastUpdated: new Date().toISOString(),
      };
    });

    res.json({
      success: true,
      sport,
      league,
      leagueName,
      seasonYear,
      count: events.length,
      events,
    });
  } catch (error: any) {
    console.error('Error fetching scoreboard from ESPN:', error.message);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch sports scoreboard',
      events: [],
    });
  }
});

// ==========================================
// MATCH DETAIL & BOX SCORE ENDPOINT
// ==========================================
app.get('/api/sports/game', async (req: Request, res: Response) => {
  const sport = (req.query.sport as string) || 'soccer';
  const league = (req.query.league as string) || 'eng.1';
  const eventId = req.query.id as string;

  if (!eventId) {
    return res.status(400).json({ success: false, message: 'Game ID is required' });
  }

  try {
    const summaryUrl = `https://site.api.espn.com/apis/site/v2/sports/${sport}/${league}/summary?event=${eventId}`;
    const rawData = await fetchWithCache(summaryUrl) as any;

    // Process boxscore team statistics
    const boxscore = rawData.boxscore || {};
    const teamsStats = boxscore.teams || [];
    const statsComparison: any[] = [];

    if (teamsStats.length >= 2) {
      const homeStats = teamsStats[1]?.statistics || [];
      const awayStats = teamsStats[0]?.statistics || [];

      homeStats.forEach((hStat: any) => {
        const aStat = awayStats.find((s: any) => s.name === hStat.name);
        if (aStat) {
          const homeNum = parseFloat(String(hStat.displayValue).replace('%', '')) || 0;
          const awayNum = parseFloat(String(aStat.displayValue).replace('%', '')) || 0;
          const total = homeNum + awayNum || 1;
          statsComparison.push({
            name: hStat.name,
            label: hStat.label || hStat.name,
            homeValue: hStat.displayValue,
            awayValue: aStat.displayValue,
            homePercentage: Math.round((homeNum / total) * 100),
            awayPercentage: Math.round((awayNum / total) * 100),
          });
        }
      });
    }

    // Process key plays / commentary
    const plays: any[] = [];
    const rawPlays = rawData.plays || rawData.keyEvents || [];
    rawPlays.slice(-30).forEach((p: any) => {
      plays.push({
        id: p.id || `p-${Math.random()}`,
        clock: p.clock?.displayValue || p.period?.displayValue || '',
        period: p.period?.number || '',
        text: p.text || p.description || '',
        type: p.scoringPlay ? 'goal' : (p.type?.text?.toLowerCase().includes('card') ? 'card' : 'general'),
        teamId: p.team?.id,
        scoringPlay: p.scoringPlay || false,
        scoreValue: p.scoreValue,
      });
    });

    // Win probability
    let winProbability = undefined;
    if (rawData.winprobability && rawData.winprobability.length > 0) {
      const latest = rawData.winprobability[rawData.winprobability.length - 1];
      winProbability = {
        homePercentage: Math.round((latest.homeWinPercentage || 0.5) * 100),
        awayPercentage: Math.round((1 - (latest.homeWinPercentage || 0.5)) * 100),
        tiePercentage: latest.tiePercentage ? Math.round(latest.tiePercentage * 100) : 0,
      };
    }

    // Standings / Article headline
    const article = rawData.article;
    const headline = article?.headline || rawData.header?.competitions?.[0]?.headlines?.[0]?.description || '';
    const summary = article?.story || rawData.header?.competitions?.[0]?.headlines?.[0]?.shortLinkText || '';

    res.json({
      success: true,
      id: eventId,
      headline,
      summary,
      stats: statsComparison,
      plays: plays.reverse(), // latest first
      winProbability,
      boxscore: rawData.boxscore,
      rosters: rawData.rosters || [],
    });
  } catch (error: any) {
    console.error('Error fetching match detail from ESPN:', error.message);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch match detail',
    });
  }
});

// ==========================================
// STANDINGS ENDPOINT
// ==========================================
app.get('/api/sports/standings', async (req: Request, res: Response) => {
  const sport = (req.query.sport as string) || 'soccer';
  const league = (req.query.league as string) || 'eng.1';

  try {
    const standingsUrl = `https://site.api.espn.com/apis/v2/sports/${sport}/${league}/standings`;
    const rawData = await fetchWithCache(standingsUrl) as any;

    const standings: any[] = [];
    const entries = rawData.children?.[0]?.standings?.entries || rawData.standings || [];

    entries.forEach((entry: any, index: number) => {
      const team = entry.team || {};
      const stats = entry.stats || [];

      const getStat = (name: string) => {
        const found = stats.find((s: any) => s.name === name || s.type === name);
        return found ? found.value ?? found.displayValue : 0;
      };

      standings.push({
        rank: index + 1,
        team: {
          id: team.id,
          name: team.name,
          displayName: team.displayName || team.name,
          abbreviation: team.abbreviation,
          logo: team.logos?.[0]?.href || team.logo,
        },
        stats: {
          gamesPlayed: getStat('gamesPlayed') || getStat('GP') || 0,
          wins: getStat('wins') || getStat('W') || 0,
          losses: getStat('losses') || getStat('L') || 0,
          ties: getStat('ties') || getStat('draws') || getStat('D') || 0,
          points: getStat('points') || getStat('PTS') || 0,
          winPercent: getStat('winPercent') || getStat('PCT') || '0.000',
          streak: getStat('streak') || getStat('STRK') || '-',
          goalDiff: getStat('pointDifferential') || getStat('goalDifference') || getStat('DIFF') || 0,
        },
      });
    });

    res.json({
      success: true,
      sport,
      league,
      standings,
    });
  } catch (error: any) {
    console.error('Error fetching standings:', error.message);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch league standings',
      standings: [],
    });
  }
});

// ==========================================
// SPORTS NEWS ENDPOINT
// ==========================================
app.get('/api/sports/news', async (req: Request, res: Response) => {
  const sport = (req.query.sport as string) || 'soccer';
  const league = (req.query.league as string) || 'eng.1';

  try {
    const newsUrl = `https://site.api.espn.com/apis/site/v2/sports/${sport}/${league}/news`;
    const rawData = await fetchWithCache(newsUrl) as any;

    const articles = (rawData.articles || []).map((art: any) => ({
      id: art.id || String(Math.random()),
      headline: art.headline,
      description: art.description,
      source: art.byline || 'Sports Desk',
      published: art.published,
      images: (art.images || []).map((img: any) => ({
        url: img.url,
        caption: img.caption,
      })),
      links: art.links || {},
      sport,
    }));

    res.json({
      success: true,
      sport,
      league,
      articles,
    });
  } catch (error: any) {
    console.error('Error fetching news:', error.message);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch sports news',
      articles: [],
    });
  }
});

// ==========================================
// GEMINI AI SPORTS ANALYST & INSIGHTS
// ==========================================
app.post('/api/sports/ai-query', async (req: Request, res: Response) => {
  const { prompt, matchContext } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const ai = getGenAI();
  if (!ai) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY is not configured. Please add GEMINI_API_KEY in the Settings menu.',
    });
  }

  try {
    let contextStr = '';
    if (matchContext) {
      contextStr = `
Match Context:
- Sport: ${matchContext.sport || 'Sports'} (${matchContext.leagueName || matchContext.league || ''})
- Match: ${matchContext.awayTeam?.displayName || 'Away'} (${matchContext.awayTeam?.score || 0}) vs ${matchContext.homeTeam?.displayName || 'Home'} (${matchContext.homeTeam?.score || 0})
- Status: ${matchContext.status?.detail || matchContext.status?.state || 'Active'}
- Venue: ${matchContext.venue?.fullName || 'Stadium'}
- Recent Plays: ${(matchContext.recentPlays || []).slice(0, 5).map((p: any) => `[${p.clock || ''}] ${p.text}`).join('; ')}
`;
    }

    const systemInstruction = `You are a world-class professional live sports commentator, tactical analyst, and sports trivia expert. 
Provide concise, vivid, accurate, and insightful breakdowns. 
Use sports terms naturally. 
When asked about live or ongoing games, highlight tactical adjustments, key performer momentum, turning points, and strategic implications.
Keep answers well formatted with Markdown bullet points and bold highlights.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `${contextStr}\n\nUser Question: ${prompt}`,
      config: {
        systemInstruction,
        temperature: 0.6,
      },
    });

    res.json({
      success: true,
      answer: response.text || 'No commentary available.',
    });
  } catch (error: any) {
    console.error('Error generating AI sports analysis:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate AI sports analysis',
    });
  }
});

// ==========================================
// VITE DEV / PRODUCTION MIDDLEWARE
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Live Sports Server running on port ${PORT}`);
  });
}

startServer();
