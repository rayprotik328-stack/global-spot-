import React, { useState } from 'react';
import { Sparkles, X, Send, Loader2, Bot, User, HelpCircle, Trophy, Activity, MessageSquare } from 'lucide-react';

interface AiAnalystDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
}

export const AiAnalystDrawer: React.FC<AiAnalystDrawerProps> = ({
  isOpen,
  onClose,
  initialPrompt,
}) => {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'ai'; text: string; time: string }>>([
    {
      sender: 'ai',
      text: "👋 Welcome to **Velocity AI Sports Intelligence** powered by Gemini 3.7. Ask me about live game telemetry, tactical systems, player form, head-to-head records, or championship odds!",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const q = textToSend || prompt;
    if (!q.trim() || loading) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setMessages((prev) => [...prev, { sender: 'user', text: q, time: timeStr }]);
    setPrompt('');
    setLoading(true);

    try {
      const res = await fetch('/api/sports/ai-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: q }),
      });

      const data = await res.json();
      if (res.ok && data.answer) {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: data.answer,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: data.error || 'Sorry, I could not generate analysis at this time.',
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: 'Network error communicating with the AI service. Please verify your connection.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="ai-analyst-sidebar"
        className="w-full max-w-lg bg-[#0F131A] border-l border-slate-800 h-full flex flex-col shadow-2xl text-slate-100"
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-[#121720] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center font-bold text-white shadow-md shadow-blue-600/30 text-sm">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Velocity AI Sports Analyst</h3>
              <p className="text-[11px] text-blue-400 font-medium">Gemini 3.7 Tactical Intelligence</p>
            </div>
          </div>
          <button
            id="btn-close-ai-drawer"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Topics */}
        <div className="p-3 bg-[#0B0E14] border-b border-slate-800/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <span className="text-[10px] uppercase font-bold text-slate-500 shrink-0">Try:</span>
          {[
            "Who's leading the Premier League title race?",
            "Key NBA playoff contenders & MVP race",
            "Top Champions League favorites",
            "Tactical trends in modern high press",
          ].map((topic, i) => (
            <button
              key={i}
              onClick={() => handleSend(topic)}
              disabled={loading}
              className="text-[11px] bg-slate-800/80 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded border border-slate-700/60 whitespace-nowrap shrink-0 transition-all disabled:opacity-50"
            >
              {topic}
            </button>
          ))}
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-3 text-xs leading-relaxed ${
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'ai' && (
                <div className="w-7 h-7 rounded bg-blue-600/20 border border-blue-500/40 flex items-center justify-center shrink-0 text-blue-400 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              
              <div
                className={`max-w-[85%] rounded-xl p-3.5 whitespace-pre-wrap ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-br-none shadow-md'
                    : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-bl-none shadow-sm'
                }`}
              >
                <p className="leading-relaxed">{msg.text}</p>
                <span className={`block text-[9px] mt-1.5 font-medium ${
                  msg.sender === 'user' ? 'text-blue-200 text-right' : 'text-slate-500'
                }`}>
                  {msg.time}
                </span>
              </div>

              {msg.sender === 'user' && (
                <div className="w-7 h-7 rounded bg-slate-700 flex items-center justify-center shrink-0 text-slate-300 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 text-xs justify-start items-center text-slate-400">
              <div className="w-7 h-7 rounded bg-blue-600/20 border border-blue-500/40 flex items-center justify-center shrink-0 text-blue-400">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 text-slate-300 flex items-center gap-2">
                <span>Analyzing sports database & match metrics...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-slate-800 bg-[#121720]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              id="input-ai-prompt"
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ask about live tactics, form, lineups, or historical stats..."
              disabled={loading}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all disabled:opacity-50"
            />
            <button
              id="btn-send-ai-prompt"
              type="submit"
              disabled={!prompt.trim() || loading}
              className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/30 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 px-1">
            <span>Powered by Google Gemini 3.7</span>
            <span>Sports Telemetry Real-time Hook</span>
          </div>
        </div>

      </div>
    </div>
  );
};
