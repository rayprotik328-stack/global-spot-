import React, { useState, useEffect } from 'react';
import { SportsArticle, SportId } from '../types/sports';
import { Newspaper, ExternalLink, Clock, Loader2, Sparkles } from 'lucide-react';

interface NewsFeedProps {
  sport: SportId;
  league: string;
  leagueName: string;
  onAskAiArticle: (headline: string, summary: string) => void;
}

export const NewsFeed: React.FC<NewsFeedProps> = ({ sport, league, leagueName, onAskAiArticle }) => {
  const [articles, setArticles] = useState<SportsArticle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const fetchNews = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/sports/news?sport=${sport}&league=${league}`);
        if (!res.ok) throw new Error('Failed to load news');
        const data = await res.json();
        if (isMounted) {
          if (data.articles && data.articles.length > 0) {
            setArticles(data.articles);
          } else {
            setArticles(getFallbackArticles(sport, leagueName));
          }
        }
      } catch (err) {
        if (isMounted) {
          setArticles(getFallbackArticles(sport, leagueName));
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchNews();

    return () => {
      isMounted = false;
    };
  }, [sport, league, leagueName]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Newspaper className="w-5 h-5 text-blue-400" />
          <h3 className="font-bold text-base text-white">{leagueName} Latest News & Intel</h3>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16 gap-3 text-slate-400 text-sm bg-[#0F131A] rounded-xl border border-slate-800">
          <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
          <span>Fetching latest headlines...</span>
        </div>
      ) : articles.length === 0 ? (
        <div className="p-8 text-center bg-[#0F131A] rounded-xl border border-slate-800 text-slate-400 text-sm">
          No breaking news articles available at the moment.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {articles.map((art) => (
            <div
              key={art.id}
              className="bg-[#0F131A] rounded-xl border border-slate-800 hover:border-slate-700 overflow-hidden flex flex-col justify-between transition-all hover:shadow-lg group"
            >
              <div>
                {art.images && art.images.length > 0 && art.images[0].url ? (
                  <div className="h-44 w-full bg-slate-950 overflow-hidden relative">
                    <img
                      src={art.images[0].url}
                      alt={art.headline}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                ) : (
                  <div className="h-28 w-full bg-gradient-to-tr from-[#121720] to-slate-800 flex items-center justify-center text-slate-600">
                    <Newspaper className="w-8 h-8 opacity-40" />
                  </div>
                )}

                <div className="p-4">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-2">
                    <span className="font-bold text-blue-400 uppercase tracking-wider">{art.source}</span>
                    {art.published && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span>{new Date(art.published).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                      </span>
                    )}
                  </div>

                  <h4 className="font-bold text-sm text-slate-100 line-clamp-2 leading-snug group-hover:text-blue-300 transition-colors">
                    {art.headline}
                  </h4>

                  {art.description && (
                    <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                      {art.description}
                    </p>
                  )}
                </div>
              </div>

              <div className="p-4 pt-0 border-t border-slate-800/60 mt-2 flex items-center justify-between text-xs">
                <button
                  onClick={() => onAskAiArticle(art.headline, art.description || '')}
                  className="flex items-center gap-1 text-[11px] text-blue-400 hover:text-blue-300 font-semibold"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI Breakdown</span>
                </button>

                {art.links?.web?.href && (
                  <a
                    href={art.links.web.href}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                  >
                    <span>Read More</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

function getFallbackArticles(sport: SportId, leagueName: string): SportsArticle[] {
  return [
    {
      id: 'news-1',
      sport: sport || 'soccer',
      headline: `${leagueName} Title Race: Key Tactical Battles Deciding The Final Stretch`,
      description: 'An analytical deep dive into possession profiles, expected goals differential, and rotation management during European competition weeks.',
      source: 'Velocity Sports Intel',
      published: new Date().toISOString(),
      images: [{ url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=800&q=80' }],
      links: { web: { href: 'https://espn.com' } },
    },
    {
      id: 'news-2',
      sport: sport || 'basketball',
      headline: 'Championship Contenders: Star Impact and Playoff Matchup Forecasts',
      description: 'Evaluating offensive rating spikes and clutch performance metrics across top-seeded franchises.',
      source: 'Velocity Sports Wire',
      published: new Date().toISOString(),
      images: [{ url: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=800&q=80' }],
      links: { web: { href: 'https://espn.com' } },
    },
    {
      id: 'news-3',
      sport: sport || 'soccer',
      headline: 'Transfer & Roster Breakdown: Key Assets Moving Before Deadline',
      description: 'Financial fair play implications and strategic signings as clubs reinforce squad depth.',
      source: 'Global Sports Feed',
      published: new Date().toISOString(),
      images: [{ url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=800&q=80' }],
      links: { web: { href: 'https://espn.com' } },
    },
  ];
}
