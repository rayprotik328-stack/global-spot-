import React from 'react';
import { 
  Trophy, 
  Search, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Sparkles, 
  Star, 
  Radio, 
  Activity,
  User
} from 'lucide-react';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  favoritesOnly: boolean;
  onToggleFavorites: () => void;
  favoritesCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  simulationMode: boolean;
  onToggleSimulation: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  liveCount: number;
  onOpenAiDrawer: () => void;
  refreshInterval: number;
  onRefreshIntervalChange: (sec: number) => void;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  onSearchChange,
  favoritesOnly,
  onToggleFavorites,
  favoritesCount,
  soundEnabled,
  onToggleSound,
  simulationMode,
  onToggleSimulation,
  onRefresh,
  isRefreshing,
  liveCount,
  onOpenAiDrawer,
  refreshInterval,
  onRefreshIntervalChange,
}) => {
  return (
    <header className="h-16 border-b border-slate-800 bg-[#121720] flex items-center justify-between px-4 sm:px-6 shrink-0 sticky top-0 z-30 shadow-md">
      
      {/* Brand & Logo */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-black italic text-white shadow-md shadow-blue-600/30 text-base select-none">
          V
        </div>
        <div className="flex items-center gap-2">
          <span className="text-lg sm:text-xl font-bold tracking-tight text-white">
            VELOCITY<span className="text-blue-500">SPORTS</span>
          </span>
          {liveCount > 0 && (
            <span className="hidden sm:inline-flex items-center gap-1.5 px-2 py-0.5 bg-red-500/10 border border-red-500/20 rounded text-red-500 text-[10px] font-bold uppercase tracking-wider animate-pulse">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
              {liveCount} LIVE
            </span>
          )}
        </div>
      </div>

      {/* Center Search Input */}
      <div className="flex-1 max-w-xs sm:max-w-sm md:max-w-md mx-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="global-sports-search"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search teams, leagues, players..."
            className="w-full bg-slate-800/60 border border-slate-700/80 rounded-full py-1.5 pl-10 pr-8 text-xs sm:text-sm text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 transition-all"
          />
          {searchQuery && (
            <button
              id="btn-clear-search"
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Action Controls & User Identity */}
      <div className="flex items-center gap-2 sm:gap-3">
        
        {/* Favorites Toggle */}
        <button
          id="btn-favorites-toggle"
          onClick={onToggleFavorites}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            favoritesOnly
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/70 hover:bg-slate-700/80'
          }`}
          title="Toggle starred favorites"
        >
          <Star className={`w-3.5 h-3.5 ${favoritesOnly ? 'fill-amber-400 text-amber-400' : 'text-slate-400'}`} />
          <span className="hidden md:inline">Favorites</span>
          {favoritesCount > 0 && (
            <span className="bg-amber-500 text-slate-950 font-bold px-1.5 py-0.2 rounded-full text-[10px]">
              {favoritesCount}
            </span>
          )}
        </button>

        {/* Live Simulation Mode */}
        <button
          id="btn-simulation-toggle"
          onClick={onToggleSimulation}
          className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            simulationMode
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/70 hover:bg-slate-700/80'
          }`}
          title="Toggle live simulation ticks"
        >
          <Activity className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">Simulator</span>
        </button>

        {/* Sound Toggle */}
        <button
          id="btn-sound-toggle"
          onClick={onToggleSound}
          className={`p-1.5 rounded-lg text-xs font-medium transition-all ${
            soundEnabled
              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
              : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-700/70'
          }`}
          title={soundEnabled ? 'Live score sound alerts enabled' : 'Muted'}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4 text-blue-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
        </button>

        {/* Refresh Action */}
        <button
          id="btn-manual-refresh"
          onClick={onRefresh}
          disabled={isRefreshing}
          className="p-1.5 rounded-lg bg-slate-800/80 border border-slate-700/70 text-slate-300 hover:text-white hover:bg-slate-700 transition-all disabled:opacity-50"
          title="Refresh match scores"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-blue-400' : ''}`} />
        </button>

        {/* AI Sports Intelligence Action Button */}
        <button
          id="btn-open-ai-analyst"
          onClick={onOpenAiDrawer}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-blue-900/30 transition-all cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">AI Analyst</span>
        </button>

        {/* User Profile Badge */}
        <div className="hidden xl:flex items-center gap-2.5 pl-2 border-l border-slate-800">
          <div className="w-7 h-7 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center text-slate-300">
            <User className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-medium text-slate-300">Alex Morgan</span>
        </div>

      </div>
    </header>
  );
};
