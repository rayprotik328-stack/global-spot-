import React from 'react';
import { SPORTS_CONFIG } from '../data/sportsConfig';
import { SportId } from '../types/sports';
import { Calendar, Radio, Flame, Award, Newspaper, BarChart3, Clock, ChevronLeft, ChevronRight } from 'lucide-react';

export type ViewTab = 'scores' | 'standings' | 'news';
export type FilterState = 'all' | 'live' | 'upcoming' | 'completed';

interface SportTabsProps {
  selectedSport: SportId;
  onSelectSport: (sport: SportId) => void;
  selectedLeague: string;
  onSelectLeague: (leagueId: string) => void;
  activeView: ViewTab;
  onSelectView: (view: ViewTab) => void;
  filterState: FilterState;
  onSelectFilter: (filter: FilterState) => void;
  liveGamesCount: Record<SportId, number>;
  dateOffset: number;
  onSelectDateOffset: (offset: number) => void;
  displayDateLabel: string;
}

export const SportTabs: React.FC<SportTabsProps> = ({
  selectedSport,
  onSelectSport,
  selectedLeague,
  onSelectLeague,
  activeView,
  onSelectView,
  filterState,
  onSelectFilter,
  liveGamesCount,
  dateOffset,
  onSelectDateOffset,
  displayDateLabel,
}) => {
  const currentSportConfig = SPORTS_CONFIG.find((s) => s.id === selectedSport) || SPORTS_CONFIG[0];
  const totalLive = (Object.values(liveGamesCount) as number[]).reduce((a, b) => a + (Number(b) || 0), 0);

  return (
    <div className="bg-[#121720] border-b border-slate-800 sticky top-16 z-20 shrink-0">
      
      {/* 1. Primary Nav Tab Bar (LIVE SCORES, STANDINGS, NEWS) */}
      <div className="h-12 border-b border-slate-800/80 flex items-center justify-between px-4 sm:px-6">
        <nav className="flex items-center gap-4 sm:gap-8 h-full text-xs sm:text-sm font-semibold tracking-wider uppercase">
          <button
            id="view-tab-scores"
            onClick={() => onSelectView('scores')}
            className={`h-full flex items-center px-1.5 transition-colors relative ${
              activeView === 'scores'
                ? 'text-blue-500 border-b-2 border-blue-500 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Live Scores
          </button>

          <button
            id="view-tab-standings"
            onClick={() => onSelectView('standings')}
            className={`h-full flex items-center px-1.5 transition-colors relative ${
              activeView === 'standings'
                ? 'text-blue-500 border-b-2 border-blue-500 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Standings
          </button>

          <button
            id="view-tab-news"
            onClick={() => onSelectView('news')}
            className={`h-full flex items-center px-1.5 transition-colors relative ${
              activeView === 'news'
                ? 'text-blue-500 border-b-2 border-blue-500 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            News & Intel
          </button>
        </nav>

        {/* Live Status Indicator Pill */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded text-red-500 text-[10px] font-bold uppercase tracking-wider">
            <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
            LIVE NOW ({totalLive})
          </div>
        </div>
      </div>

      {/* 2. Sub-Row: Sports Selector & Date / Filters */}
      <div className="px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 bg-[#0F131A]/90">
        
        {/* Sports Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {SPORTS_CONFIG.map((sport) => {
            const isSelected = selectedSport === sport.id;
            const liveCount = liveGamesCount[sport.id] || 0;

            return (
              <button
                key={sport.id}
                id={`tab-sport-${sport.id}`}
                onClick={() => onSelectSport(sport.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                  isSelected
                    ? 'bg-blue-600/20 text-blue-400 border border-blue-500/40 shadow-sm'
                    : 'bg-slate-800/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-700/60'
                }`}
              >
                <span>{sport.icon}</span>
                <span>{sport.name}</span>
                {liveCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
                    {liveCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Controls: League Dropdown & Date Navigator */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap ml-auto">
          
          {/* Leagues inside selected sport */}
          <div className="flex items-center gap-1 bg-slate-800/80 p-0.5 rounded-lg border border-slate-700/80 text-xs">
            {currentSportConfig.leagues.map((lg) => {
              const isLgSelected = selectedLeague === lg.id;
              return (
                <button
                  key={lg.id}
                  id={`tab-league-${lg.id}`}
                  onClick={() => onSelectLeague(lg.id)}
                  className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                    isLgSelected
                      ? 'bg-blue-600 text-white font-bold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {lg.name}
                </button>
              );
            })}
          </div>

          {/* Date Navigator */}
          {activeView === 'scores' && (
            <div className="flex items-center bg-slate-800/80 rounded-lg border border-slate-700/80 p-0.5 text-xs text-slate-300">
              <button
                id="btn-date-prev"
                onClick={() => onSelectDateOffset(dateOffset - 1)}
                className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-700 transition-all"
                title="Previous Day"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>

              <button
                id="btn-date-today"
                onClick={() => onSelectDateOffset(0)}
                className={`px-2.5 py-1 font-semibold transition-all rounded ${
                  dateOffset === 0
                    ? 'text-blue-400'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {displayDateLabel}
              </button>

              <button
                id="btn-date-next"
                onClick={() => onSelectDateOffset(dateOffset + 1)}
                className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-700 transition-all"
                title="Next Day"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Match Filter (All, Live, Upcoming, Final) */}
          {activeView === 'scores' && (
            <div className="flex items-center bg-slate-800/80 p-0.5 rounded-lg border border-slate-700/80 text-xs">
              <button
                id="filter-all"
                onClick={() => onSelectFilter('all')}
                className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                  filterState === 'all' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All
              </button>
              <button
                id="filter-live"
                onClick={() => onSelectFilter('live')}
                className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                  filterState === 'live' ? 'bg-red-600/30 text-red-400 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Live
              </button>
              <button
                id="filter-upcoming"
                onClick={() => onSelectFilter('upcoming')}
                className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                  filterState === 'upcoming' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Upcoming
              </button>
              <button
                id="filter-completed"
                onClick={() => onSelectFilter('completed')}
                className={`px-2.5 py-1 rounded-md transition-all font-medium ${
                  filterState === 'completed' ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Final
              </button>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
