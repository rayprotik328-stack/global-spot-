import React from 'react';
import { MatchGame } from '../types/sports';
import { formatMatchTime } from '../utils/date';
import { Star, Tv, MapPin, Sparkles, ChevronRight, Activity, TrendingUp } from 'lucide-react';

interface ScoreCardProps {
  match: MatchGame;
  isFavorite: boolean;
  onToggleFavorite: (matchId: string, teamName: string) => void;
  onSelectMatch: (match: MatchGame) => void;
  onAskAi: (match: MatchGame) => void;
}

export const ScoreCard: React.FC<ScoreCardProps> = ({
  match,
  isFavorite,
  onToggleFavorite,
  onSelectMatch,
  onAskAi,
}) => {
  const { status, homeTeam, awayTeam, venue, broadcasts, recentPlays, winProbability, odds, headline } = match;

  const isLive = status.isLive;
  const isFinal = status.completed || status.state === 'post';
  const isScheduled = status.state === 'pre';

  // Latest play event
  const latestPlay = recentPlays && recentPlays.length > 0 ? recentPlays[0] : null;

  return (
    <div 
      id={`scorecard-${match.id}`}
      className={`group relative bg-slate-900/60 border rounded-xl transition-all duration-200 hover:border-slate-700 hover:shadow-lg overflow-hidden flex flex-col justify-between ${
        isLive 
          ? 'border-blue-500/40 bg-gradient-to-b from-[#121720] via-slate-900/70 to-blue-950/10' 
          : 'border-slate-800 bg-[#0F131A]/70'
      }`}
    >
      {/* Top Meta Bar */}
      <div className="px-4 py-2.5 flex items-center justify-between border-b border-slate-800/80 bg-[#121720]/80">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            {match.leagueName || match.league}
          </span>
          <span className="text-slate-600">•</span>
          
          {isLive ? (
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              {status.detail || 'LIVE'}
            </span>
          ) : isFinal ? (
            <span className="text-[10px] font-bold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded">
              {status.detail || 'FINAL'}
            </span>
          ) : (
            <span className="text-[10px] font-semibold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">
              {formatMatchTime(match.date)}
            </span>
          )}
        </div>

        {/* Favorite Button */}
        <button
          id={`btn-fav-${match.id}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(match.id, `${homeTeam.name} vs ${awayTeam.name}`);
          }}
          className="p-1 rounded text-slate-500 hover:text-amber-400 transition-colors"
          title={isFavorite ? 'Remove favorite' : 'Add favorite'}
        >
          <Star className={`w-3.5 h-3.5 ${isFavorite ? 'fill-amber-400 text-amber-400' : ''}`} />
        </button>
      </div>

      {/* Main Scoreboard Body */}
      <div 
        className="p-4 cursor-pointer flex-1 flex flex-col justify-between"
        onClick={() => onSelectMatch(match)}
      >
        <div className="space-y-3">
          
          {/* Away Team Row */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <div className="w-6 h-6 rounded-md bg-slate-800 border border-slate-700/80 p-0.5 flex items-center justify-center shrink-0 overflow-hidden">
                {awayTeam.logo ? (
                  <img
                    src={awayTeam.logo}
                    alt={awayTeam.displayName}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                    onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                  />
                ) : (
                  <div className="w-3.5 h-3.5 bg-blue-600 rounded-sm"></div>
                )}
              </div>

              <div className="min-w-0">
                <p className={`text-sm font-semibold truncate ${
                  awayTeam.isWinner ? 'text-white font-bold' : 'text-slate-200'
                }`}>
                  {awayTeam.displayName}
                </p>
                {awayTeam.records && (
                  <span className="text-[10px] text-slate-500 font-medium truncate block">
                    {awayTeam.records}
                  </span>
                )}
              </div>
            </div>

            <div className="shrink-0 text-right">
              {isScheduled ? (
                <span className="text-xs font-semibold text-slate-500">-</span>
              ) : (
                <span className={`text-xl sm:text-2xl font-black tabular-nums ${
                  awayTeam.isWinner ? 'text-blue-400' : isLive ? 'text-white' : 'text-slate-300'
                }`}>
                  {awayTeam.score}
                </span>
              )}
            </div>
          </div>

          {/* Home Team Row */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <div className="w-6 h-6 rounded-md bg-slate-800 border border-slate-700/80 p-0.5 flex items-center justify-center shrink-0 overflow-hidden">
                {homeTeam.logo ? (
                  <img
                    src={homeTeam.logo}
                    alt={homeTeam.displayName}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                    onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                  />
                ) : (
                  <div className="w-3.5 h-3.5 bg-indigo-600 rounded-sm"></div>
                )}
              </div>

              <div className="min-w-0">
                <p className={`text-sm font-semibold truncate ${
                  homeTeam.isWinner ? 'text-white font-bold' : 'text-slate-200'
                }`}>
                  {homeTeam.displayName}
                </p>
                {homeTeam.records && (
                  <span className="text-[10px] text-slate-500 font-medium truncate block">
                    {homeTeam.records}
                  </span>
                )}
              </div>
            </div>

            <div className="shrink-0 text-right">
              {isScheduled ? (
                <span className="text-xs font-semibold text-slate-500">-</span>
              ) : (
                <span className={`text-xl sm:text-2xl font-black tabular-nums ${
                  homeTeam.isWinner ? 'text-blue-400' : isLive ? 'text-white' : 'text-slate-300'
                }`}>
                  {homeTeam.score}
                </span>
              )}
            </div>
          </div>

        </div>

        {/* Live Momentum / Play Ticker */}
        {latestPlay && isLive && (
          <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-[11px] flex items-center gap-2 text-slate-400">
            <Activity className="w-3 h-3 text-emerald-400 shrink-0" />
            <span className="truncate text-slate-300">
              <span className="font-semibold text-emerald-400">{latestPlay.clock}</span>: {latestPlay.text}
            </span>
          </div>
        )}

        {/* Win Probability or Odds Bar */}
        {winProbability && (
          <div className="mt-3 pt-2 border-t border-slate-800/60">
            <div className="flex justify-between text-[10px] text-slate-400 mb-1 font-semibold uppercase">
              <span>{awayTeam.abbreviation || 'AWY'} {winProbability.away}%</span>
              <span>Win Prob</span>
              <span>{homeTeam.abbreviation || 'HOM'} {winProbability.home}%</span>
            </div>
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden flex">
              <div 
                className="bg-blue-500 h-full transition-all duration-500" 
                style={{ width: `${winProbability.away}%` }} 
              />
              <div 
                className="bg-indigo-500 h-full transition-all duration-500" 
                style={{ width: `${winProbability.home}%` }} 
              />
            </div>
          </div>
        )}

      </div>

      {/* Footer Strip */}
      <div className="px-4 py-2 border-t border-slate-800/80 bg-[#0B0E14]/80 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2 truncate">
          {venue?.fullName && (
            <span className="flex items-center gap-1 truncate text-slate-400">
              <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
              <span className="truncate">{venue.fullName}</span>
            </span>
          )}
          {odds?.details && (
            <span className="bg-slate-800 px-1.5 py-0.5 rounded text-[10px] text-slate-300 font-semibold shrink-0">
              {odds.details}
            </span>
          )}
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onAskAi(match);
          }}
          className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-bold ml-2 shrink-0 transition-colors"
          title="AI Tactical Intelligence"
        >
          <Sparkles className="w-3 h-3" />
          <span className="text-[10px] uppercase">AI Intel</span>
        </button>
      </div>

    </div>
  );
};
