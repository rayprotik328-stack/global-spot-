import React, { useState, useEffect } from 'react';
import { MatchGame, PlayByPlayEvent, MatchStat } from '../types/sports';
import { formatMatchTime } from '../utils/date';
import { 
  X, 
  Sparkles, 
  Activity, 
  BarChart2, 
  ListOrdered, 
  MapPin, 
  Tv, 
  TrendingUp, 
  Send, 
  Loader2,
  Calendar,
  AlertCircle,
  Volume2
} from 'lucide-react';
import { playWhistleSound, playBuzzerSound } from '../utils/audio';

interface MatchDetailModalProps {
  match: MatchGame | null;
  onClose: () => void;
}

export const MatchDetailModal: React.FC<MatchDetailModalProps> = ({ match, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'boxscore' | 'plays' | 'ai'>('overview');
  const [extraStats, setExtraStats] = useState<MatchStat[]>([]);
  const [detailedPlays, setDetailedPlays] = useState<PlayByPlayEvent[]>([]);
  const [loadingDetails, setLoadingDetails] = useState(false);
  
  // AI analysis state
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiResponses, setAiResponses] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([]);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    if (!match) return;

    // Reset tab and state
    setActiveTab('overview');
    setAiResponses([]);
    setExtraStats(match.stats || []);
    setDetailedPlays(match.recentPlays || []);

    // Fetch deep game summary from backend if available
    const fetchGameDetails = async () => {
      if (match.id.startsWith('sim-')) return; // sample match already has data

      try {
        setLoadingDetails(true);
        const res = await fetch(`/api/sports/game?sport=${match.sport}&league=${match.league}&id=${match.id}`);
        if (res.ok) {
          const data = await res.json();
          if (data.stats && data.stats.length > 0) {
            setExtraStats(data.stats);
          }
          if (data.plays && data.plays.length > 0) {
            setDetailedPlays(data.plays);
          }
        }
      } catch (err) {
        console.error('Error fetching game details:', err);
      } finally {
        setLoadingDetails(false);
      }
    };

    fetchGameDetails();
  }, [match]);

  if (!match) return null;

  const { status, homeTeam, awayTeam, venue, broadcasts, winProbability, odds } = match;
  const isLive = status.isLive;

  // Handle asking AI in the match modal
  const handleSendAiPrompt = async (promptText: string) => {
    if (!promptText.trim()) return;

    const userMsg = promptText;
    setAiQuestion('');
    setAiResponses((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setAiLoading(true);

    try {
      const res = await fetch('/api/sports/ai-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMsg,
          matchContext: {
            ...match,
            stats: extraStats,
            recentPlays: detailedPlays,
          },
        }),
      });

      const data = await res.json();
      if (res.ok && data.answer) {
        setAiResponses((prev) => [...prev, { sender: 'ai', text: data.answer }]);
      } else {
        setAiResponses((prev) => [
          ...prev, 
          { sender: 'ai', text: data.error || 'Unable to retrieve AI analysis at this moment.' }
        ]);
      }
    } catch (err: any) {
      setAiResponses((prev) => [
        ...prev, 
        { sender: 'ai', text: 'Network connection issue while communicating with AI service.' }
      ]);
    } finally {
      setAiLoading(false);
    }
  };

  const playTestAlert = () => {
    if (match.sport === 'soccer') {
      playWhistleSound();
    } else {
      playBuzzerSound();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        id="match-detail-dialog"
        className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-100"
      >
        
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="px-2.5 py-1 rounded-md text-xs font-bold uppercase bg-slate-800 text-slate-300">
              {match.leagueName || match.league}
            </span>
            {isLive ? (
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                LIVE • {status.detail}
              </span>
            ) : status.completed ? (
              <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-800 text-slate-300">
                {status.detail || 'Final'}
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-950/40 text-emerald-400 border border-emerald-800/40">
                {formatMatchTime(match.date)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={playTestAlert}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1"
              title="Test Sport Whistle/Buzzer Sound"
            >
              <Volume2 className="w-3.5 h-3.5" />
            </button>
            <button
              id="btn-close-modal"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Big Scoreboard Banner */}
        <div className="p-6 bg-gradient-to-b from-slate-950 to-slate-900 border-b border-slate-800/80">
          <div className="grid grid-cols-1 md:grid-cols-7 gap-4 items-center">
            
            {/* Away Team (Left) */}
            <div className="md:col-span-3 flex items-center justify-start md:justify-end gap-4 text-left md:text-right">
              <div className="order-2 md:order-1">
                <h3 className="font-extrabold text-lg sm:text-xl text-white tracking-tight">
                  {awayTeam.displayName}
                </h3>
                {awayTeam.records && (
                  <p className="text-xs text-slate-400 font-medium">{awayTeam.records}</p>
                )}
              </div>
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-800/80 border border-slate-700/80 p-2 flex items-center justify-center shrink-0 shadow-lg order-1 md:order-2">
                {awayTeam.logo ? (
                  <img src={awayTeam.logo} alt={awayTeam.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                ) : (
                  <span className="font-black text-slate-300">{awayTeam.abbreviation}</span>
                )}
              </div>
            </div>

            {/* Score Center (Middle) */}
            <div className="md:col-span-1 text-center py-2 bg-slate-800/40 rounded-xl border border-slate-700/40">
              <div className="flex items-center justify-center gap-3 text-3xl sm:text-4xl font-black tabular-nums tracking-tight">
                <span className={awayTeam.isWinner ? 'text-emerald-400' : 'text-white'}>{awayTeam.score}</span>
                <span className="text-slate-600 text-2xl font-light">-</span>
                <span className={homeTeam.isWinner ? 'text-emerald-400' : 'text-white'}>{homeTeam.score}</span>
              </div>
              <div className="text-[11px] font-semibold text-slate-400 mt-1">
                {status.clock ? status.clock : status.detail}
              </div>
            </div>

            {/* Home Team (Right) */}
            <div className="md:col-span-3 flex items-center justify-start gap-4">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-slate-800/80 border border-slate-700/80 p-2 flex items-center justify-center shrink-0 shadow-lg">
                {homeTeam.logo ? (
                  <img src={homeTeam.logo} alt={homeTeam.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                ) : (
                  <span className="font-black text-slate-300">{homeTeam.abbreviation}</span>
                )}
              </div>
              <div>
                <h3 className="font-extrabold text-lg sm:text-xl text-white tracking-tight">
                  {homeTeam.displayName}
                </h3>
                {homeTeam.records && (
                  <p className="text-xs text-slate-400 font-medium">{homeTeam.records}</p>
                )}
              </div>
            </div>

          </div>

          {/* Meta Info Bar: Venue, Odds, TV */}
          <div className="mt-4 pt-3 border-t border-slate-800/60 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
            <div className="flex items-center gap-4 flex-wrap">
              {venue?.fullName && (
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{venue.fullName} {venue.city ? `(${venue.city})` : ''}</span>
                </span>
              )}
              {broadcasts && broadcasts.length > 0 && (
                <span className="flex items-center gap-1.5">
                  <Tv className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{broadcasts.join(', ')}</span>
                </span>
              )}
            </div>
            {odds?.details && (
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium text-[11px]">
                Odds: {odds.details} {odds.overUnder ? `• O/U ${odds.overUnder}` : ''}
              </span>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 border-b border-slate-800 bg-[#0F131A] flex gap-6 text-xs font-bold uppercase tracking-wider">
          <button
            id="tab-modal-overview"
            onClick={() => setActiveTab('overview')}
            className={`py-3.5 flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Match Overview</span>
          </button>

          <button
            id="tab-modal-boxscore"
            onClick={() => setActiveTab('boxscore')}
            className={`py-3.5 flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'boxscore'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Linescores & Stats</span>
          </button>

          <button
            id="tab-modal-plays"
            onClick={() => setActiveTab('plays')}
            className={`py-3.5 flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'plays'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ListOrdered className="w-3.5 h-3.5" />
            <span>Play-by-Play ({detailedPlays.length})</span>
          </button>

          <button
            id="tab-modal-ai"
            onClick={() => {
              setActiveTab('ai');
              if (aiResponses.length === 0) {
                handleSendAiPrompt(`Give me a quick tactical summary, key moments, and momentum breakdown for this match: ${awayTeam.displayName} vs ${homeTeam.displayName}.`);
              }
            }}
            className={`py-3.5 flex items-center gap-1.5 border-b-2 transition-all ${
              activeTab === 'ai'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>AI Tactical Intel</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="p-6 overflow-y-auto max-h-[55vh] space-y-6">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              
              {/* Win Probability Section */}
              {winProbability && (
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                  <div className="flex justify-between items-center text-xs font-bold text-slate-300 mb-2">
                    <span className="text-cyan-400">{awayTeam.displayName} {winProbability.awayPercentage}%</span>
                    <span className="text-slate-400 font-medium">Win Probability</span>
                    <span className="text-emerald-400">{winProbability.homePercentage}% {homeTeam.displayName}</span>
                  </div>
                  <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
                    <div className="h-full bg-cyan-500 transition-all duration-500" style={{ width: `${winProbability.awayPercentage}%` }} />
                    {winProbability.tiePercentage && winProbability.tiePercentage > 0 && (
                      <div className="h-full bg-slate-600 transition-all duration-500" style={{ width: `${winProbability.tiePercentage}%` }} />
                    )}
                    <div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: `${winProbability.homePercentage}%` }} />
                  </div>
                </div>
              )}

              {/* Key Timeline Events (Goals, Cards, Scores) */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  Key Match Events
                </h4>
                {detailedPlays.length === 0 ? (
                  <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800/80 text-center text-xs text-slate-500">
                    No major scoring events recorded yet.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {detailedPlays.slice(0, 8).map((play) => (
                      <div 
                        key={play.id}
                        className={`p-3 rounded-xl border text-xs flex items-center gap-3 transition-all ${
                          play.scoringPlay 
                            ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-100' 
                            : 'bg-slate-950/50 border-slate-800 text-slate-300'
                        }`}
                      >
                        <span className="font-mono font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded text-[11px] shrink-0">
                          {play.clock || `${play.period || ''}`}
                        </span>
                        <div className="flex-1">
                          <p className="font-medium leading-relaxed">{play.text}</p>
                        </div>
                        {play.teamAbbr && (
                          <span className="font-bold text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded shrink-0">
                            {play.teamAbbr}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Head to Head Stats Comparison */}
              {extraStats.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                    <BarChart2 className="w-4 h-4 text-emerald-400" />
                    Team Statistics
                  </h4>
                  <div className="space-y-3 bg-slate-950/50 p-4 rounded-xl border border-slate-800">
                    {extraStats.map((stat, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-bold text-slate-200 tabular-nums">{stat.awayValue}</span>
                          <span className="text-slate-400 font-medium">{stat.label}</span>
                          <span className="font-bold text-slate-200 tabular-nums">{stat.homeValue}</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden flex">
                          <div 
                            className="h-full bg-cyan-500" 
                            style={{ width: `${stat.awayPercentage || 50}%` }} 
                          />
                          <div 
                            className="h-full bg-emerald-500" 
                            style={{ width: `${stat.homePercentage || 50}%` }} 
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB 2: BOX SCORE & LINESCORES */}
          {activeTab === 'boxscore' && (
            <div className="space-y-6">
              
              {/* Linescore Table */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Period / Quarter Scoring Breakdown
                </h4>
                <div className="overflow-x-auto bg-slate-950/60 rounded-xl border border-slate-800 p-2">
                  <table className="w-full text-xs text-center">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="text-left py-2 px-3">Team</th>
                        {(awayTeam.linescores || [{ period: 1 }, { period: 2 }]).map((_, idx) => (
                          <th key={idx} className="py-2 px-2.5">
                            {match.sport === 'soccer' ? (idx === 0 ? '1H' : '2H') : (idx + 1)}
                          </th>
                        ))}
                        <th className="py-2 px-3 font-bold text-white">T</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-medium">
                      {/* Away Row */}
                      <tr>
                        <td className="text-left py-2.5 px-3 flex items-center gap-2">
                          <span className="font-bold text-slate-200">{awayTeam.abbreviation}</span>
                        </td>
                        {(awayTeam.linescores || []).map((ls, idx) => (
                          <td key={idx} className="py-2.5 px-2.5 text-slate-300 tabular-nums">
                            {ls.displayValue || ls.value}
                          </td>
                        ))}
                        <td className="py-2.5 px-3 font-bold text-emerald-400 text-sm tabular-nums">
                          {awayTeam.score}
                        </td>
                      </tr>
                      {/* Home Row */}
                      <tr>
                        <td className="text-left py-2.5 px-3 flex items-center gap-2">
                          <span className="font-bold text-slate-200">{homeTeam.abbreviation}</span>
                        </td>
                        {(homeTeam.linescores || []).map((ls, idx) => (
                          <td key={idx} className="py-2.5 px-2.5 text-slate-300 tabular-nums">
                            {ls.displayValue || ls.value}
                          </td>
                        ))}
                        <td className="py-2.5 px-3 font-bold text-emerald-400 text-sm tabular-nums">
                          {homeTeam.score}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Complete Match Stats Grid */}
              {extraStats.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                    Boxscore Statistical Summary
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {extraStats.map((st, i) => (
                      <div key={i} className="bg-slate-950/40 p-3 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                        <span className="font-bold text-cyan-400">{st.awayValue}</span>
                        <span className="text-slate-400 font-medium">{st.label}</span>
                        <span className="font-bold text-emerald-400">{st.homeValue}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB 3: COMPLETE PLAY-BY-PLAY */}
          {activeTab === 'plays' && (
            <div className="space-y-3">
              {detailedPlays.length === 0 ? (
                <div className="p-6 text-center text-slate-500 text-xs bg-slate-950/40 rounded-xl border border-slate-800">
                  No chronological plays logged for this event yet.
                </div>
              ) : (
                detailedPlays.map((play) => (
                  <div 
                    key={play.id}
                    className={`p-3 rounded-xl border text-xs flex items-start gap-3 ${
                      play.scoringPlay 
                        ? 'bg-emerald-950/30 border-emerald-700/50 text-emerald-100 font-medium' 
                        : 'bg-slate-950/40 border-slate-800 text-slate-300'
                    }`}
                  >
                    <span className="font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded text-[11px] shrink-0 mt-0.5">
                      {play.clock || `${play.period || ''}`}
                    </span>
                    <p className="flex-1 leading-relaxed">{play.text}</p>
                    {play.teamAbbr && (
                      <span className="font-bold text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded shrink-0">
                        {play.teamAbbr}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 4: AI TACTICAL INTELLIGENCE */}
          {activeTab === 'ai' && (
            <div className="space-y-4">
              
              <div className="bg-gradient-to-r from-emerald-950/40 to-slate-950 p-4 rounded-xl border border-emerald-800/30 text-xs text-emerald-200 flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <p>
                  Powered by <strong>Gemini 3.7</strong> sports analytics. Ask about tactical match-ups, momentum shifts, key player performance, or predicted outcomes!
                </p>
              </div>

              {/* AI Conversation Stream */}
              <div className="space-y-3 min-h-[160px]">
                {aiResponses.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`p-4 rounded-xl text-xs leading-relaxed whitespace-pre-wrap ${
                      msg.sender === 'user' 
                        ? 'bg-slate-800 text-white ml-8 font-medium' 
                        : 'bg-slate-950 border border-slate-800 text-slate-200 mr-4 shadow-sm'
                    }`}
                  >
                    {msg.sender === 'ai' && (
                      <div className="flex items-center gap-1.5 text-emerald-400 font-bold mb-2 text-[11px]">
                        <Sparkles className="w-3 h-3" />
                        AI Sports Analyst
                      </div>
                    )}
                    {msg.text}
                  </div>
                ))}

                {aiLoading && (
                  <div className="flex items-center gap-2 p-4 bg-slate-950 border border-slate-800 rounded-xl text-xs text-emerald-400">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Analyzing live match telemetry and match dynamics...</span>
                  </div>
                )}
              </div>

              {/* Preset prompt pills */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {[
                  'Who has the tactical momentum right now?',
                  'Analyze key player matchups & impact',
                  'What adjustments does the trailing team need?',
                  'Explain key turning points in this match'
                ].map((promptText, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendAiPrompt(promptText)}
                    disabled={aiLoading}
                    className="text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700/80 transition-all disabled:opacity-50"
                  >
                    {promptText}
                  </button>
                ))}
              </div>

              {/* Input field */}
              <div className="flex gap-2 pt-2">
                <input
                  type="text"
                  value={aiQuestion}
                  onChange={(e) => setAiQuestion(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSendAiPrompt(aiQuestion);
                  }}
                  placeholder="Ask anything about this match..."
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
                <button
                  onClick={() => handleSendAiPrompt(aiQuestion)}
                  disabled={aiLoading || !aiQuestion.trim()}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-900/30"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Ask</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
