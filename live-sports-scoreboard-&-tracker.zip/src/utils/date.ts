export function formatMatchTime(isoString: string): string {
  if (!isoString) return '';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return isoString;

  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();

  const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (isToday) {
    return `Today, ${timeStr}`;
  }

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  if (date.toDateString() === tomorrow.toDateString()) {
    return `Tomorrow, ${timeStr}`;
  }

  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) {
    return `Yesterday, ${timeStr}`;
  }

  return `${date.toLocaleDateString([], { month: 'short', day: 'numeric' })}, ${timeStr}`;
}

export function formatShortDate(date: Date): string {
  return date.toISOString().slice(0, 10).replace(/-/g, '');
}

export function getDisplayDateLabel(dateOffset: number): { label: string; date: Date; dateParam: string } {
  const d = new Date();
  d.setDate(d.getDate() + dateOffset);

  let label = d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
  if (dateOffset === 0) label = 'Today';
  if (dateOffset === 1) label = 'Tomorrow';
  if (dateOffset === -1) label = 'Yesterday';

  return {
    label,
    date: d,
    dateParam: formatShortDate(d),
  };
}
