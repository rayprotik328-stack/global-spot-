import { LeagueInfo, SportId } from '../types/sports';

export interface SportCategory {
  id: SportId;
  name: string;
  icon: string;
  leagues: LeagueInfo[];
}

export const SPORTS_CONFIG: SportCategory[] = [
  {
    id: 'soccer',
    name: 'Soccer',
    icon: '⚽',
    leagues: [
      { id: 'eng.1', name: 'Premier League', shortName: 'EPL', sport: 'soccer', sportPath: 'soccer', leaguePath: 'eng.1' },
      { id: 'esp.1', name: 'La Liga', shortName: 'La Liga', sport: 'soccer', sportPath: 'soccer', leaguePath: 'esp.1' },
      { id: 'uefa.champions', name: 'UEFA Champions League', shortName: 'UCL', sport: 'soccer', sportPath: 'soccer', leaguePath: 'uefa.champions' },
      { id: 'ita.1', name: 'Serie A', shortName: 'Serie A', sport: 'soccer', sportPath: 'soccer', leaguePath: 'ita.1' },
      { id: 'ger.1', name: 'Bundesliga', shortName: 'Bundesliga', sport: 'soccer', sportPath: 'soccer', leaguePath: 'ger.1' },
      { id: 'fra.1', name: 'Ligue 1', shortName: 'Ligue 1', sport: 'soccer', sportPath: 'soccer', leaguePath: 'fra.1' },
      { id: 'usa.1', name: 'Major League Soccer', shortName: 'MLS', sport: 'soccer', sportPath: 'soccer', leaguePath: 'usa.1' },
    ],
  },
  {
    id: 'basketball',
    name: 'Basketball',
    icon: '🏀',
    leagues: [
      { id: 'nba', name: 'NBA', shortName: 'NBA', sport: 'basketball', sportPath: 'basketball', leaguePath: 'nba' },
      { id: 'wnba', name: 'WNBA', shortName: 'WNBA', sport: 'basketball', sportPath: 'basketball', leaguePath: 'wnba' },
      { id: 'mens-college-basketball', name: "NCAA Men's Basketball", shortName: 'NCAA', sport: 'basketball', sportPath: 'basketball', leaguePath: 'mens-college-basketball' },
    ],
  },
  {
    id: 'baseball',
    name: 'Baseball',
    icon: '⚾',
    leagues: [
      { id: 'mlb', name: 'Major League Baseball', shortName: 'MLB', sport: 'baseball', sportPath: 'baseball', leaguePath: 'mlb' },
    ],
  },
  {
    id: 'football',
    name: 'American Football',
    icon: '🏈',
    leagues: [
      { id: 'nfl', name: 'NFL', shortName: 'NFL', sport: 'football', sportPath: 'football', leaguePath: 'nfl' },
      { id: 'college-football', name: 'NCAA College Football', shortName: 'CFB', sport: 'football', sportPath: 'football', leaguePath: 'college-football' },
    ],
  },
  {
    id: 'hockey',
    name: 'Hockey',
    icon: '🏒',
    leagues: [
      { id: 'nhl', name: 'NHL', shortName: 'NHL', sport: 'hockey', sportPath: 'hockey', leaguePath: 'nhl' },
    ],
  },
  {
    id: 'tennis',
    name: 'Tennis',
    icon: '🎾',
    leagues: [
      { id: 'atp', name: 'ATP Tour', shortName: 'ATP', sport: 'tennis', sportPath: 'tennis', leaguePath: 'atp' },
      { id: 'wta', name: 'WTA Tour', shortName: 'WTA', sport: 'tennis', sportPath: 'tennis', leaguePath: 'wta' },
    ],
  },
  {
    id: 'racing',
    name: 'Formula 1',
    icon: '🏎️',
    leagues: [
      { id: 'f1', name: 'Formula 1', shortName: 'F1', sport: 'racing', sportPath: 'racing', leaguePath: 'f1' },
    ],
  },
  {
    id: 'cricket',
    name: 'Cricket',
    icon: '🏏',
    leagues: [
      { id: 'icc', name: 'ICC International', shortName: 'ICC', sport: 'cricket', sportPath: 'cricket', leaguePath: 'icc' },
      { id: 'ipl', name: 'Indian Premier League', shortName: 'IPL', sport: 'cricket', sportPath: 'cricket', leaguePath: 'ipl' },
    ],
  },
];
