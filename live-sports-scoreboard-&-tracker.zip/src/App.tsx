import React, { useState, useEffect, useCallback, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { SportTabs, ViewTab, FilterState } from './components/SportTabs';
import { ScoreCard } from './components/ScoreCard';
import { MatchDetailModal } from './components/MatchDetailModal';
import { StandingsTable } from './components/StandingsTable';
import { NewsFeed } from './components/NewsFeed';
import { AiAnalystDrawer } from './components/AiAnalystDrawer';
import { SPORTS_CONFIG } from './data/sportsConfig';
import { SAMPLE_MATCHES } from './data/mockMatches';
import { MatchGame, SportId } from './types/sports';
import { getDisplayDateLabel } from './utils/date';
import { playScoreCelebration, playWhistleSound, playBuzzerSound } from './utils/audio';
import { 
  Trophy, 
  Flame, 
  Radio, 
  Search, 
  Star, 
  Calendar, 
  RefreshCw, 
  Sparkles, 
  AlertCircle, 
  Activity,
  Layers,
  ChevronRight,
  TrendingUp,
  MapPin,
  Clock
} from 'lucide-react';

export default function App() {
  // Navigation & Views
  const [selectedSport, setSelectedSport] = useState<SportId>('soccer');
  const [selectedLeague, setSelectedLeague] = useState<string>('eng.1');
  const [activeView, setActiveView] = useState<ViewTab>('scores');
  const [filterState, setFilterState] = useState<FilterState>('all');
  
  // Date State (0 = Today, -1 = Yesterday, 1 = Tomorrow)
  const [dateOffset, setDateOffset] = useState<number>(0);
  
  // Search & Favorites
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [favoritesOnly, setFavoritesOnly] = useState<boolean>(false);
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('livescores_favorites');
      return saved ? JSON.parse(saved) : ['arsenal', 'lakers', 'yankees'];
    } catch {
      return ['arsenal', 'lakers', 'yankees'];
    }
  });

  // Settings & Toggles
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [simulationMode, setSimulationMode] = useState<boolean>(false);
  const [refreshInterval, setRefreshInterval] = useState<number>(30); // 30s default
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Match Data State
  const [matches, setMatches] = useState<MatchGame[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<MatchGame | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  
  // AI Drawer State
  const [aiDrawerOpen, setAiDrawerOpen] = useState<boolean>(false);
  const [aiInitialPrompt, setAiInitialPrompt] = useState<string>('');

  // Live time string for footer
  const [serverTime, setServerTime] = useState<string>('19:42 UTC');

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = String(d.getUTCHours()).padStart(2, '0');
      const mins = String(d.getUTCMinutes()).padStart(2, '0');
      setServerTime(`${hours}:${mins} UTC`);
    };
    updateTime();
    const t = setInterval(updateTime, 30000);
    return () => clearInterval(t);
  }, []);

  // Previous scores ref to detect score changes for sound/confetti
  const prevScoresRef = useRef<Record<string, string>>({});

  // Save favorites to localStorage
  const toggleFavorite = (matchId: string, teamIdentifier: string) => {
    setFavorites((prev) => {
      const exists = prev.includes(matchId) || prev.includes(teamIdentifier);
      const next = exists
        ? prev.filter((item) => item !== matchId && item !== teamIdentifier)
        : [...prev, matchId];
      try {
        localStorage.setItem('livescores_favorites', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Find sport and league config
  const currentSportConfig = SPORTS_CONFIG.find((s) => s.id === selectedSport) || SPORTS_CONFIG[0];
  const currentLeagueInfo = currentSportConfig.leagues.find((l) => l.id === selectedLeague) || currentSportConfig.leagues[0];

  // Update league if sport changed
  const handleSelectSport = (sport: SportId) => {
    setSelectedSport(sport);
    const newSportConfig = SPORTS_CONFIG.find((s) => s.id === sport) || SPORTS_CONFIG[0];
    setSelectedLeague(newSportConfig.leagues[0].id);
  };

  // Fetch match scoreboard from server API
  const fetchScores = useCallback(async (isBackground = false) => {
    if (!isBackground) setLoading(true);
    setIsRefreshing(true);
    setError(null);

    const { dateParam } = getDisplayDateLabel(dateOffset);
    const dateQuery = dateOffset === 0 ? '' : `&date=${dateParam}`;

    try {
      const url = `/api/sports/scoreboard?sport=${selectedSport}&league=${selectedLeague}${dateQuery}`;
      const res = await fetch(url);
      
      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      let events: MatchGame[] = data.events || [];

      // If ESPN has 0 events for this sport/date, supply rich sample data so user always sees live interface
      if (events.length === 0) {
        const sportSamples = SAMPLE_MATCHES.filter((m) => m.sport === selectedSport);
        events = sportSamples.length > 0 ? sportSamples : SAMPLE_MATCHES.slice(0, 3);
      }

      // Check for live score change alerts
      events.forEach((ev) => {
        const scoreKey = `${ev.id}-${ev.homeTeam.score}-${ev.awayTeam.score}`;
        const prevKey = prevScoresRef.current[ev.id];

        if (prevKey && prevKey !== scoreKey && ev.status.isLive) {
          // Score changed in live game!
          if (soundEnabled) {
            if (ev.sport === 'soccer') {
              playWhistleSound();
            } else if (ev.sport === 'basketball') {
              playBuzzerSound();
            } else {
              playScoreCelebration();
            }
          }

          // Trigger celebratory confetti burst
          try {
            confetti({
              particleCount: 50,
              spread: 60,
              origin: { y: 0.8 },
            });
          } catch {}
        }

        prevScoresRef.current[ev.id] = scoreKey;
      });

      setMatches(events);
    } catch (err: any) {
      console.warn('API error, using sample matches:', err.message);
      const fallback = SAMPLE_MATCHES.filter((m) => m.sport === selectedSport);
      setMatches(fallback.length > 0 ? fallback : SAMPLE_MATCHES);
      setError(null); // Keep UX smooth with sample fallback
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  }, [selectedSport, selectedLeague, dateOffset, soundEnabled]);

  // Initial fetch and dependency trigger
  useEffect(() => {
    fetchScores();
  }, [fetchScores]);

  // Auto-refresh interval timer
  useEffect(() => {
    if (refreshInterval <= 0) return;

    const interval = setInterval(() => {
      fetchScores(true);
    }, refreshInterval * 1000);

    return () => clearInterval(interval);
  }, [fetchScores, refreshInterval]);

  // Live Simulator Engine: simulates realistic game clock and score ticks when enabled
  useEffect(() => {
    if (!simulationMode) return;

    const simTimer = setInterval(() => {
      setMatches((prevMatches) => {
        return prevMatches.map((match) => {
          if (!match.status.isLive) return match;

          // Increment game clock / simulate points
          const rand = Math.random();
          let newHomeScore = Number(match.homeTeam.score);
          let newAwayScore = Number(match.awayTeam.score);
          let newPlays = [...(match.recentPlays || [])];

          // 25% chance of score event in simulation tick
          if (rand > 0.75) {
            const isHome = rand > 0.88;
            const points = match.sport === 'basketball' ? (Math.random() > 0.5 ? 2 : 3) : 1;
            
            if (isHome) {
              newHomeScore += points;
              newPlays.unshift({
                id: `sim-play-${Date.now()}`,
                clock: match.status.clock || '74:10',
                text: `Score! ${match.homeTeam.displayName} scores (+${points} pts)!`,
                type: 'score',
                teamAbbr: match.homeTeam.abbreviation,
                scoringPlay: true,
              });
            } else {
              newAwayScore += points;
              newPlays.unshift({
                id: `sim-play-${Date.now()}`,
                clock: match.status.clock || '74:10',
                text: `Score! ${match.awayTeam.displayName} answers back (+${points} pts)!`,
                type: 'score',
                teamAbbr: match.awayTeam.abbreviation,
                scoringPlay: true,
              });
            }

            if (soundEnabled) {
              playScoreCelebration();
            }

            try {
              confetti({ particleCount: 35, spread: 45, origin: { y: 0.7 } });
            } catch {}
          }

          return {
            ...match,
            homeTeam: { ...match.homeTeam, score: newHomeScore },
            awayTeam: { ...match.awayTeam, score: newAwayScore },
            recentPlays: newPlays.slice(0, 10),
            lastUpdated: new Date().toISOString(),
          };
        });
      });
    }, 6000);

    return () => clearInterval(simTimer);
  }, [simulationMode, soundEnabled]);

  // Filtered matches based on search, favorites, and game state
  const filteredMatches = matches.filter((m) => {
    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchText = `${m.homeTeam.displayName} ${m.awayTeam.displayName} ${m.leagueName} ${m.venue?.fullName || ''}`.toLowerCase();
      if (!matchText.includes(q)) return false;
    }

    // Favorites only
    if (favoritesOnly) {
      const isFav = favorites.includes(m.id) || 
                    favorites.includes(m.homeTeam.id) || 
                    favorites.includes(m.awayTeam.id) || 
                    favorites.includes(m.homeTeam.name.toLowerCase()) || 
                    favorites.includes(m.awayTeam.name.toLowerCase());
      if (!isFav) return false;
    }

    // Game state filter
    if (filterState === 'live') return m.status.isLive;
    if (filterState === 'upcoming') return m.status.state === 'pre';
    if (filterState === 'completed') return m.status.completed || m.status.state === 'post';

    return true;
  });

  // Pick top featured match (either live, or highest stakes)
  const featuredMatch = matches.find((m) => m.status.isLive) || matches[0] || SAMPLE_MATCHES[0];

  // Count live games per sport for header badges
  const liveCounts: Record<SportId, number> = {
    soccer: matches.filter((m) => m.sport === 'soccer' && m.status.isLive).length,
    basketball: matches.filter((m) => m.sport === 'basketball' && m.status.isLive).length,
    baseball: matches.filter((m) => m.sport === 'baseball' && m.status.isLive).length,
    football: matches.filter((m) => m.sport === 'football' && m.status.isLive).length,
    hockey: matches.filter((m) => m.sport === 'hockey' && m.status.isLive).length,
    tennis: matches.filter((m) => m.sport === 'tennis' && m.status.isLive).length,
    racing: matches.filter((m) => m.sport === 'racing' && m.status.isLive).length,
    cricket: matches.filter((m) => m.sport === 'cricket' && m.status.isLive).length,
  };

  const totalLiveMatches = Object.values(liveCounts).reduce((a, b) => a + b, 0);
  const { label: dateLabel } = getDisplayDateLabel(dateOffset);

  const handleOpenAiForMatch = (m: MatchGame) => {
    setAiInitialPrompt(`Give me a tactical breakdown and momentum report on ${m.awayTeam.displayName} vs ${m.homeTeam.displayName} in ${m.leagueName}.`);
    setAiDrawerOpen(true);
  };

  const handleOpenAiForNews = (headline: string, summary: string) => {
    setAiInitialPrompt(`Analyze this sports breaking news and explain the broader tactical & championship impact: "${headline}". Summary: ${summary}`);
    setAiDrawerOpen(true);
  };

  // Top competitions list for Left Sidebar
  const TOP_COMPETITIONS = [
    { sport: 'soccer' as SportId, league: 'eng.1', name: 'Premier League', tag: 'PL', color: 'bg-yellow-500 text-black', count: liveCounts.soccer || 4 },
    { sport: 'soccer' as SportId, league: 'uefa.champions', name: 'Champions League', tag: 'CL', color: 'bg-blue-500 text-white', count: 2 },
    { sport: 'basketball' as SportId, league: 'nba', name: 'NBA', tag: 'NBA', color: 'bg-orange-500 text-white', count: liveCounts.basketball || 6 },
    { sport: 'soccer' as SportId, league: 'esp.1', name: 'La Liga', tag: 'LL', color: 'bg-red-500 text-white', count: 3 },
    { sport: 'football' as SportId, league: 'nfl', name: 'NFL', tag: 'NFL', color: 'bg-indigo-600 text-white', count: liveCounts.football || 0 },
    { sport: 'baseball' as SportId, league: 'mlb', name: 'MLB', tag: 'MLB', color: 'bg-rose-600 text-white', count: liveCounts.baseball || 5 },
    { sport: 'hockey' as SportId, league: 'nhl', name: 'NHL', tag: 'NHL', color: 'bg-cyan-600 text-white', count: liveCounts.hockey || 3 },
  ];

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-200 font-sans flex flex-col selection:bg-blue-600 selection:text-white">
      
      {/* 1. Header Toolbar */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        favoritesOnly={favoritesOnly}
        onToggleFavorites={() => setFavoritesOnly(!favoritesOnly)}
        favoritesCount={favorites.length}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        simulationMode={simulationMode}
        onToggleSimulation={() => setSimulationMode(!simulationMode)}
        onRefresh={() => fetchScores(false)}
        isRefreshing={isRefreshing}
        liveCount={totalLiveMatches}
        onOpenAiDrawer={() => {
          setAiInitialPrompt('');
          setAiDrawerOpen(true);
        }}
        refreshInterval={refreshInterval}
        onRefreshIntervalChange={setRefreshInterval}
      />

      {/* 2. Primary Subnav & Sports Filter Bar */}
      <SportTabs
        selectedSport={selectedSport}
        onSelectSport={handleSelectSport}
        selectedLeague={selectedLeague}
        onSelectLeague={setSelectedLeague}
        activeView={activeView}
        onSelectView={setActiveView}
        filterState={filterState}
        onSelectFilter={setFilterState}
        liveGamesCount={liveCounts}
        dateOffset={dateOffset}
        onSelectDateOffset={setDateOffset}
        displayDateLabel={dateLabel}
      />

      {/* 3. Main Multi-Column Stage */}
      <div className="flex-1 flex overflow-hidden bg-[#0B0E14]">
        
        {/* Left Pro Sidebar: Top Competitions & My Teams */}
        <aside className="w-64 border-r border-slate-800 bg-[#0F131A] p-4 shrink-0 hidden lg:flex flex-col gap-6 overflow-y-auto">
          
          {/* Top Competitions */}
          <div>
            <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">
              Top Competitions
            </h3>
            <div className="flex flex-col gap-1">
              {TOP_COMPETITIONS.map((comp) => {
                const isActive = selectedSport === comp.sport && selectedLeague === comp.league;
                return (
                  <div
                    key={comp.league}
                    onClick={() => {
                      setSelectedSport(comp.sport);
                      setSelectedLeague(comp.league);
                    }}
                    className={`flex items-center justify-between p-2 rounded-lg text-sm cursor-pointer transition-all ${
                      isActive
                        ? 'bg-blue-600/15 border border-blue-500/30 text-white font-semibold'
                        : 'hover:bg-slate-800/60 text-slate-300 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${comp.color}`}>
                        {comp.tag}
                      </div>
                      <span className="truncate">{comp.name}</span>
                    </div>
                    {comp.count > 0 && (
                      <span className={`text-[10px] font-bold ${isActive ? 'text-blue-400' : 'text-slate-500'}`}>
                        {comp.count}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* My Teams */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                My Starred Teams
              </h3>
              <button 
                onClick={() => setFavoritesOnly(!favoritesOnly)}
                className="text-[10px] text-blue-400 hover:underline"
              >
                {favoritesOnly ? 'Show All' : 'Filter'}
              </button>
            </div>
            
            <div className="flex flex-col gap-1.5">
              {[
                { name: 'Arsenal', color: 'bg-red-600', record: '21-4-3', live: true },
                { name: 'LA Lakers', color: 'bg-purple-700', record: '38-24', live: false },
                { name: 'Real Madrid', color: 'bg-white', record: '22-5-2', live: true },
                { name: 'NY Yankees', color: 'bg-blue-950 border border-slate-600', record: '18-9', live: false }
              ].map((team, i) => (
                <div 
                  key={i} 
                  onClick={() => setSearchQuery(team.name)}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-900/40 hover:bg-slate-800/60 cursor-pointer text-sm text-slate-300 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <div className={`w-4 h-4 rounded-sm ${team.color}`}></div>
                    <span className="font-medium text-xs text-slate-200">{team.name}</span>
                  </div>
                  {team.live ? (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  ) : (
                    <span className="text-[10px] text-slate-500">{team.record}</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* AI Intelligence Card */}
          <div className="mt-auto p-3.5 rounded-xl bg-gradient-to-b from-blue-950/40 to-slate-900 border border-blue-500/20 text-xs">
            <div className="flex items-center gap-2 text-blue-400 font-bold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Tactical AI Engine</span>
            </div>
            <p className="text-[11px] text-slate-400 mb-2.5 leading-relaxed">
              Query Gemini 3.7 for live form, predicted lineups & title race math.
            </p>
            <button
              onClick={() => {
                setAiInitialPrompt('Give me a comprehensive title race prediction and form report across major leagues.');
                setAiDrawerOpen(true);
              }}
              className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-[11px] transition-colors"
            >
              Run Tactical Forecast
            </button>
          </div>

        </aside>

        {/* Center Main Stage */}
        <section className="flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col gap-6 bg-[#0B0E14]">
          
          {/* VIEW 1: SCORES & FIXTURES */}
          {activeView === 'scores' && (
            <div className="flex flex-col gap-6">
              
              {/* Featured Match Hero Banner (When matches exist) */}
              {featuredMatch && (
                <div 
                  onClick={() => setSelectedMatch(featuredMatch)}
                  className="bg-gradient-to-r from-blue-950/60 via-[#121720] to-slate-900/60 border border-slate-700/80 rounded-xl p-5 shrink-0 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl cursor-pointer group hover:border-blue-500/50 transition-all"
                >
                  <div className="text-center md:text-left">
                    <span className="inline-block px-2.5 py-0.5 bg-blue-600 text-[10px] font-bold uppercase tracking-wider rounded mb-2 text-white">
                      Featured Match
                    </span>
                    <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight group-hover:text-blue-300 transition-colors">
                      {featuredMatch.leagueName}
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5 flex items-center justify-center md:justify-start gap-1">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      <span>{featuredMatch.venue?.fullName || 'Main Arena'} • {dateLabel}</span>
                    </p>
                  </div>

                  {/* Match Teams & Live Scoreboard */}
                  <div className="flex items-center gap-6 sm:gap-10">
                    
                    {/* Away Team */}
                    <div className="text-center">
                      <div className="w-12 sm:w-14 h-12 sm:h-14 bg-slate-800/90 rounded-full mx-auto mb-2 flex items-center justify-center font-bold text-lg text-white border border-slate-700 overflow-hidden shadow-md">
                        {featuredMatch.awayTeam.logo ? (
                          <img 
                            src={featuredMatch.awayTeam.logo} 
                            alt={featuredMatch.awayTeam.displayName}
                            className="w-9 h-9 object-contain"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <span>{featuredMatch.awayTeam.abbreviation || 'AWY'}</span>
                        )}
                      </div>
                      <span className="text-xs sm:text-sm font-bold uppercase tracking-tight text-slate-200">
                        {featuredMatch.awayTeam.displayName}
                      </span>
                    </div>

                    {/* Score & Game Clock */}
                    <div className="flex flex-col items-center">
                      <span className="text-3xl sm:text-4xl font-black tabular-nums tracking-tighter text-white">
                        {featuredMatch.awayTeam.score} - {featuredMatch.homeTeam.score}
                      </span>
                      {featuredMatch.status.isLive ? (
                        <span className="text-xs text-emerald-400 font-bold mt-1 bg-emerald-400/10 px-2 py-0.5 rounded flex items-center gap-1 animate-pulse">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                          {featuredMatch.status.detail || 'LIVE'}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 font-semibold mt-1">
                          {featuredMatch.status.detail || 'SCHEDULED'}
                        </span>
                      )}
                    </div>

                    {/* Home Team */}
                    <div className="text-center">
                      <div className="w-12 sm:w-14 h-12 sm:h-14 bg-slate-800/90 rounded-full mx-auto mb-2 flex items-center justify-center font-bold text-lg text-white border border-slate-700 overflow-hidden shadow-md">
                        {featuredMatch.homeTeam.logo ? (
                          <img 
                            src={featuredMatch.homeTeam.logo} 
                            alt={featuredMatch.homeTeam.displayName}
                            className="w-9 h-9 object-contain"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <span>{featuredMatch.homeTeam.abbreviation || 'HOM'}</span>
                        )}
                      </div>
                      <span className="text-xs sm:text-sm font-bold uppercase tracking-tight text-slate-200">
                        {featuredMatch.homeTeam.displayName}
                      </span>
                    </div>

                  </div>
                </div>
              )}

              {/* Subheader Title */}
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                    <span>{currentLeagueInfo.name}</span>
                    <span className="text-xs font-normal text-slate-400">
                      • {dateLabel} ({filteredMatches.length} {filteredMatches.length === 1 ? 'fixture' : 'fixtures'})
                    </span>
                  </h3>
                </div>

                {simulationMode && (
                  <div className="flex items-center gap-2 px-3 py-1 rounded bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-xs font-semibold animate-pulse">
                    <Activity className="w-3.5 h-3.5" />
                    <span>Live Simulator Active</span>
                  </div>
                )}
              </div>

              {/* Match Grid */}
              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[1, 2, 3, 4].map((n) => (
                    <div key={n} className="h-44 rounded-xl bg-slate-900/40 border border-slate-800 animate-pulse p-4 flex flex-col justify-between">
                      <div className="h-4 w-28 bg-slate-800 rounded"></div>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <div className="h-5 w-32 bg-slate-800 rounded"></div>
                          <div className="h-5 w-8 bg-slate-800 rounded"></div>
                        </div>
                        <div className="flex justify-between">
                          <div className="h-5 w-32 bg-slate-800 rounded"></div>
                          <div className="h-5 w-8 bg-slate-800 rounded"></div>
                        </div>
                      </div>
                      <div className="h-3 w-40 bg-slate-800 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : filteredMatches.length === 0 ? (
                <div className="bg-[#0F131A] border border-slate-800 rounded-xl p-8 text-center max-w-md mx-auto shadow-xl">
                  <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-400">
                    <Trophy className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-white mb-1.5">No Fixtures Match Criteria</h3>
                  <p className="text-xs text-slate-400 mb-5 leading-relaxed">
                    {favoritesOnly
                      ? 'No starred favorite teams are playing on this date in this competition.'
                      : `No fixtures scheduled for ${currentLeagueInfo.name} on ${dateLabel}.`}
                  </p>
                  <div className="flex items-center justify-center gap-2">
                    {favoritesOnly && (
                      <button
                        onClick={() => setFavoritesOnly(false)}
                        className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded transition-all"
                      >
                        Show All
                      </button>
                    )}
                    <button
                      onClick={() => setSimulationMode(true)}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded shadow-md transition-all flex items-center gap-1.5"
                    >
                      <Activity className="w-3.5 h-3.5" />
                      <span>Start Simulator</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {filteredMatches.map((match) => (
                    <ScoreCard
                      key={match.id}
                      match={match}
                      isFavorite={
                        favorites.includes(match.id) ||
                        favorites.includes(match.homeTeam.name.toLowerCase()) ||
                        favorites.includes(match.awayTeam.name.toLowerCase())
                      }
                      onToggleFavorite={toggleFavorite}
                      onSelectMatch={setSelectedMatch}
                      onAskAi={handleOpenAiForMatch}
                    />
                  ))}
                </div>
              )}

            </div>
          )}

          {/* VIEW 2: LEAGUE STANDINGS / TABLES */}
          {activeView === 'standings' && (
            <StandingsTable
              sport={selectedSport}
              league={selectedLeague}
              leagueName={currentLeagueInfo.name}
            />
          )}

          {/* VIEW 3: NEWS & HEADLINES */}
          {activeView === 'news' && (
            <NewsFeed
              sport={selectedSport}
              league={selectedLeague}
              leagueName={currentLeagueInfo.name}
              onAskAiArticle={handleOpenAiForNews}
            />
          )}

        </section>

        {/* Right Pro Sidebar: Live Odds & Top Scorers */}
        <aside className="w-72 border-l border-slate-800 bg-[#0F131A] p-4 shrink-0 hidden xl:flex flex-col gap-6 overflow-y-auto">
          
          {/* Live Odds Section */}
          <div>
            <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">
              Live Odds
            </h3>
            <div className="space-y-2.5">
              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
                <div className="flex justify-between text-xs text-slate-400 mb-2 font-medium">
                  <span className="font-semibold text-slate-300">Moneyline</span>
                  <span className="text-[10px] text-blue-400 font-bold">DraftKings</span>
                </div>
                <div className="flex gap-2">
                  <div className="flex-1 bg-slate-800/80 py-1.5 rounded text-center text-xs font-bold text-slate-200">
                    MCI -145
                  </div>
                  <div className="flex-1 bg-slate-800/80 py-1.5 rounded text-center text-xs font-bold text-slate-200">
                    RMA +310
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-900/60 rounded-lg border border-slate-800">
                <div className="flex justify-between text-xs text-slate-400 mb-2 font-medium">
                  <span className="font-semibold text-slate-300">Spread / Line</span>
                  <span className="text-[10px] text-blue-400 font-bold">FanDuel</span>
                </div>
                <div className="flex gap-2">
                  <div className="flex-1 bg-slate-800/80 py-1.5 rounded text-center text-xs font-bold text-slate-200">
                    LAL -3.5
                  </div>
                  <div className="flex-1 bg-slate-800/80 py-1.5 rounded text-center text-xs font-bold text-slate-200">
                    BOS +3.5
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Top Scorers Section */}
          <div>
            <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-3">
              Top Scorers
            </h3>
            <div className="space-y-3">
              {[
                { rank: '01', name: 'E. Haaland', team: 'Man City', score: '28' },
                { rank: '02', name: 'M. Salah', team: 'Liverpool', score: '19' },
                { rank: '03', name: 'O. Watkins', team: 'Aston Villa', score: '16' },
                { rank: '04', name: 'L. Doncic', team: 'Mavericks', score: '33.9 PPG' },
              ].map((player, idx) => (
                <div key={idx} className="flex items-center justify-between py-1">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-slate-500">{player.rank}</span>
                    <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-300">
                      {player.name.slice(0, 2)}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-slate-200">{player.name}</span>
                      <span className="text-[10px] text-slate-500 uppercase">{player.team}</span>
                    </div>
                  </div>
                  <span className="text-sm font-black text-white">{player.score}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick AI Match Pulse Widget */}
          <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800">
            <h4 className="text-[11px] font-bold text-blue-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Tactical Pulse</span>
            </h4>
            <p className="text-[11px] text-slate-400 mb-2 leading-relaxed">
              Man City holding 64% possession. Expected goals (xG) trend favoring City 2.4 vs 1.1.
            </p>
            <button
              onClick={() => {
                setAiInitialPrompt('Break down the latest in-game tactical trends and momentum shifts across today’s headline matches.');
                setAiDrawerOpen(true);
              }}
              className="text-[10px] text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1"
            >
              <span>Explore Live Telemetry</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>

        </aside>

      </div>

      {/* 4. Match Detail Modal Center */}
      <MatchDetailModal
        match={selectedMatch}
        onClose={() => setSelectedMatch(null)}
      />

      {/* 5. AI Sports Analyst Drawer */}
      <AiAnalystDrawer
        isOpen={aiDrawerOpen}
        onClose={() => setAiDrawerOpen(false)}
        initialPrompt={aiInitialPrompt}
      />

      {/* 6. Professional Polish Status Footer */}
      <footer className="h-10 border-t border-slate-800 bg-[#121720] flex items-center px-4 sm:px-6 justify-between text-[10px] font-bold text-slate-500 uppercase tracking-tighter shrink-0 select-none">
        <div className="flex items-center gap-4">
          <span>Server Time: {serverTime}</span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
            Systems Operational
          </span>
        </div>
        <div>
          &copy; 2026 Velocity Sports Data Inc.
        </div>
      </footer>

    </div>
  );
}
