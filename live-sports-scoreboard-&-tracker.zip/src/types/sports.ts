export type SportId = 'soccer' | 'basketball' | 'baseball' | 'football' | 'hockey' | 'tennis' | 'racing' | 'cricket';

export interface LeagueInfo {
  id: string;
  name: string;
  shortName: string;
  sport: SportId;
  sportPath: string;
  leaguePath: string;
  icon?: string;
}

export type GameStatusState = 'pre' | 'in' | 'post' | 'delayed' | 'postponed' | 'canceled';

export interface TeamScore {
  id: string;
  name: string;
  displayName: string;
  shortDisplayName: string;
  abbreviation: string;
  logo?: string;
  color?: string;
  alternateColor?: string;
  score: string | number;
  records?: string; // e.g. "24-12" or "(1st in East)"
  isWinner?: boolean;
  linescores?: Array<{
    value: number | string;
    period?: number | string;
    displayValue?: string;
  }>;
  statistics?: Array<{
    name: string;
    displayValue: string;
    label: string;
  }>;
}

export interface PlayByPlayEvent {
  id: string;
  time?: string;
  clock?: string;
  period?: number | string;
  text: string;
  type?: 'goal' | 'card' | 'score' | 'foul' | 'sub' | 'general' | 'touchdown' | 'three_pointer' | 'home_run';
  teamId?: string;
  teamLogo?: string;
  teamAbbr?: string;
  scoringPlay?: boolean;
  scoreValue?: number;
}

export interface MatchStat {
  name: string;
  label: string;
  homeValue: string | number;
  awayValue: string | number;
  homePercentage?: number;
  awayPercentage?: number;
}

export interface MatchGame {
  id: string;
  uid?: string;
  sport: SportId;
  league: string;
  leagueName: string;
  seasonYear?: number;
  date: string; // ISO date
  status: {
    state: GameStatusState;
    detail: string; // "74'", "Final", "Q3 4:12", "Top 7th", "7:30 PM EDT"
    shortDetail: string;
    clock?: string;
    period?: number | string;
    completed: boolean;
    isLive: boolean;
  };
  homeTeam: TeamScore;
  awayTeam: TeamScore;
  venue?: {
    fullName?: string;
    city?: string;
    state?: string;
    country?: string;
  };
  broadcasts?: string[];
  winProbability?: {
    homePercentage: number;
    awayPercentage: number;
    tiePercentage?: number;
  };
  headline?: string;
  summary?: string;
  recentPlays?: PlayByPlayEvent[];
  stats?: MatchStat[];
  odds?: {
    details?: string;
    overUnder?: number;
    spread?: string;
  };
  lastUpdated?: string;
}

export interface StandingTeam {
  rank: number;
  team: {
    id: string;
    name: string;
    displayName: string;
    abbreviation: string;
    logo?: string;
  };
  stats: {
    gamesPlayed: number;
    wins: number;
    losses: number;
    ties?: number;
    points?: number;
    winPercent?: string;
    streak?: string;
    goalDiff?: number;
    pointsFor?: number;
    pointsAgainst?: number;
    form?: string[]; // e.g. ['W', 'D', 'L', 'W', 'W']
  };
}

export interface SportsArticle {
  id: string;
  headline: string;
  description: string;
  source: string;
  published: string;
  images: Array<{
    url: string;
    caption?: string;
  }>;
  links: {
    web?: {
      href: string;
    };
  };
  sport: SportId;
}

export interface AiMatchAnalysis {
  matchId: string;
  summary: string;
  keyTactics: string[];
  momentumAnalysis: string;
  notablePerformers: string[];
  predictionOrVerdict: string;
  confidenceScore: number;
  suggestedQuestions: string[];
}
